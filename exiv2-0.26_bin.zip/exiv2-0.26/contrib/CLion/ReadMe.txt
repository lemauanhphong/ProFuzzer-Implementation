CLion is an awesome IDE/Editor.

1) Copy the idea directory to <exiv2dir>/.idea
2) Open the directory in CLion

I don't know how this works, however it enables CLion to build and debug exiv2.
Developed on Unix.  Works without modification on MacOS-X.
Probably works with Cygwin and MinGW.

Thanks very much to Ben for providing this.

Robin Mills
robin@clanmills
2016-08-26
